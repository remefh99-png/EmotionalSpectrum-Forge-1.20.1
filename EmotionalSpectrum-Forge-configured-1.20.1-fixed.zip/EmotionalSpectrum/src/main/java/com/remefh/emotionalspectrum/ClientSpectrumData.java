package com.remefh.emotionalspectrum;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.loading.FMLEnvironment;

public final class ClientSpectrumData {
    public static final String[] COLOURS = {
        "green", "yellow", "red", "blue", "orange", "indigo", "violet", "black", "white"
    };
    public static final int[] ENERGY = new int[9];
    public static final int[] MAX = new int[9];
    public static String ACTIVE = "";

    public static void update(int[] energy, int[] max, String active) {
        if (FMLEnvironment.dist != Dist.CLIENT) return;
        System.arraycopy(energy, 0, ENERGY, 0, Math.min(9, energy.length));
        System.arraycopy(max, 0, MAX, 0, Math.min(9, max.length));
        ACTIVE = active;
    }

    private ClientSpectrumData() {}
}
