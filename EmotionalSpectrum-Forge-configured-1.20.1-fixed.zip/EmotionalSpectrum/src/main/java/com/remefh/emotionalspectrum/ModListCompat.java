package com.remefh.emotionalspectrum;

import net.minecraftforge.fml.ModList;

public final class ModListCompat {
    public static boolean curiosLoaded() { return ModList.get().isLoaded("curios"); }
    private ModListCompat() {}
}
