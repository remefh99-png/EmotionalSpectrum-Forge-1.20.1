package com.remefh.emotionalspectrum;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class RingActionPacket {
    private final int action; // 0 = cycle selected colour, 1 = activate selected colour

    public RingActionPacket(int action) { this.action = action; }

    public static void encode(RingActionPacket packet, FriendlyByteBuf buffer) {
        buffer.writeVarInt(packet.action);
    }

    public static RingActionPacket decode(FriendlyByteBuf buffer) {
        return new RingActionPacket(buffer.readVarInt());
    }

    public static void handle(RingActionPacket packet, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player == null) return;
            if (packet.action == 0) SpectrumLogic.cycle(player);
            else if (packet.action == 1) SpectrumLogic.activate(player);
            else if (packet.action == 2) SpectrumLogic.toggleFlight(player);
            else if (packet.action == 3) SpectrumLogic.activateBeam(player);
            else if (packet.action == 4) SpectrumLogic.activateConstruct(player);
        });
        context.setPacketHandled(true);
    }
}
