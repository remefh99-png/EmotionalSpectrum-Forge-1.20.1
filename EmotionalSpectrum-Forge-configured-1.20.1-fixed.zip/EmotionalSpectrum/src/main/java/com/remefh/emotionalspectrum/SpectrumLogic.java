package com.remefh.emotionalspectrum;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.ClipContext;
import net.minecraft.world.phys.HitResult;
import org.joml.Vector3f;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.network.chat.Component;
import top.theillusivec4.curios.api.CuriosApi;

import java.util.ArrayList;
import java.util.List;

public final class SpectrumLogic {
    public static final String[] COLOURS = {
        "green", "yellow", "red", "blue", "orange", "indigo", "violet", "black", "white"
    };

    public static int countRings(ServerPlayer player, String colour) {
        return CuriosApi.getCuriosInventory(player).map(handler -> {
            int[] count = {0};
            handler.getCurios().values().forEach(stacksHandler -> {
                for (int i = 0; i < stacksHandler.getSlots(); i++) {
                    ItemStack stack = stacksHandler.getStacks().getStackInSlot(i);
                    if (stack.getItem() instanceof LanternRingItem ring
                            && ring.getSpectrum().equals(colour)) {
                        count[0] += stack.getCount();
                    }
                }
            });
            return count[0];
        }).orElse(0);
    }

    public static List<String> availableColours(ServerPlayer player) {
        List<String> result = new ArrayList<>();
        for (String colour : COLOURS) {
            if (countRings(player, colour) > 0) result.add(colour);
        }
        return result;
    }

    public static void cycle(ServerPlayer player) {
        List<String> available = availableColours(player);
        if (available.isEmpty()) {
            player.displayClientMessage(Component.literal("§cНадень кольцо Фонарей в слот Curios Ring."), true);
            return;
        }
        String current = player.getPersistentData().getString("es_active_colour");
        int index = available.indexOf(current);
        String next = available.get((index + 1) % available.size());
        player.getPersistentData().putString("es_active_colour", next);
        player.displayClientMessage(Component.literal("§fВыбран корпус: " + displayName(next)
                + " §7| §bЭнергия: " + energy(player, next) + "/" + (countRings(player, next) * 1000)), true);
    }

    public static int energy(ServerPlayer player, String colour) {
        return player.getPersistentData().getInt("es_" + colour + "_energy");
    }

    public static void activate(ServerPlayer player) {
        String colour = player.getPersistentData().getString("es_active_colour");
        if (colour.isEmpty() || countRings(player, colour) == 0) {
            player.displayClientMessage(Component.literal("§cСначала надень кольцо и выбери корпус клавишей R."), true);
            return;
        }
        int cost = 100;
        int current = energy(player, colour);
        if (current < cost) {
            player.displayClientMessage(Component.literal("§cНедостаточно энергии " + displayName(colour) + "!"), true);
            return;
        }
        player.getPersistentData().putInt("es_" + colour + "_energy", current - cost);
        usePower(player, colour);
        player.displayClientMessage(Component.literal("§b-" + cost + " энергии §7(" + displayName(colour) + ")"), true);
    }

    private static void usePower(ServerPlayer player, String colour) {
        List<LivingEntity> nearby = player.level().getEntitiesOfClass(
                LivingEntity.class, player.getBoundingBox().inflate(6.0),
                entity -> entity != player && entity.isAlive());
        List<LivingEntity> enemies = nearby.stream()
                .filter(entity -> !player.isAlliedTo(entity)).toList();

        switch (colour) {
            case "green" -> {
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 160, 1));
                player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 160, 1));
            }
            case "yellow" -> enemies.forEach(e -> e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 1)));
            case "red" -> enemies.forEach(e -> e.hurt(player.damageSources().magic(), 7.0F));
            case "blue" -> {
                player.heal(8.0F);
                player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 160, 1));
            }
            case "orange" -> {
                player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 300, 2));
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 160, 0));
            }
            case "indigo" -> {
                player.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 120, 0));
                enemies.forEach(e -> e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 120, 1)));
            }
            case "violet" -> {
                player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 1));
                nearby.stream().filter(e -> player.isAlliedTo(e))
                        .forEach(e -> e.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 1)));
            }
            case "black" -> enemies.forEach(e -> e.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 1)));
            case "white" -> {
                player.heal(12.0F);
                player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 240, 2));
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 160, 0));
            }
        }
    }


    public static void activateBeam(ServerPlayer player) {
        String colour = player.getPersistentData().getString("es_active_colour");
        if (colour.isEmpty() || countRings(player, colour) == 0) {
            player.displayClientMessage(Component.literal("§cСначала надень кольцо и выбери корпус клавишей R."), true);
            return;
        }
        int cost = 150;
        int current = energy(player, colour);
        if (current < cost) {
            player.displayClientMessage(Component.literal("§cНедостаточно энергии " + displayName(colour) + "!"), true);
            return;
        }
        player.getPersistentData().putInt("es_" + colour + "_energy", current - cost);

        ServerLevel level = player.serverLevel();
        Vec3 start = player.getEyePosition();
        Vec3 look = player.getLookAngle().normalize();
        Vec3 requestedEnd = start.add(look.scale(24.0));
        BlockHitResult blockHit = level.clip(new ClipContext(start, requestedEnd,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        Vec3 end = blockHit.getType() == HitResult.Type.MISS ? requestedEnd : blockHit.getLocation();

        Vector3f rgb = colourVector(colour);
        DustParticleOptions dust = new DustParticleOptions(rgb, 1.25F);
        double distance = start.distanceTo(end);
        int points = Math.max(2, (int)(distance * 3));
        for (int i = 0; i <= points; i++) {
            Vec3 point = start.lerp(end, (double)i / points);
            level.sendParticles(dust, point.x, point.y, point.z, 2, 0.035, 0.035, 0.035, 0.0);
        }

        AABB beamBox = new AABB(start, end).inflate(0.65);
        LivingEntity target = level.getEntitiesOfClass(LivingEntity.class, beamBox,
                e -> e != player && e.isAlive() && !player.isAlliedTo(e)).stream()
                .filter(e -> e.getBoundingBox().inflate(0.25).clip(start, end).isPresent())
                .min((a, b) -> Double.compare(a.distanceToSqr(start), b.distanceToSqr(start)))
                .orElse(null);
        if (target != null) {
            float damage = switch (colour) {
                case "red", "black" -> 10.0F;
                case "white", "green" -> 6.0F;
                default -> 7.0F;
            };
            target.hurt(player.damageSources().magic(), damage);
            target.invulnerableTime = 0;
            if (colour.equals("yellow")) target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 2));
            if (colour.equals("blue") || colour.equals("violet")) player.heal(3.0F);
            if (colour.equals("black")) target.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 1));
            if (colour.equals("indigo")) target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 1));
        }
        player.displayClientMessage(Component.literal("§bЭнергетический луч: §f" + displayName(colour)
                + " §7(-" + cost + ")"), true);
    }

    /** Creates a short-lived, colour-specific hard-light formation around/in front of the player. */
    public static void activateConstruct(ServerPlayer player) {
        String colour = player.getPersistentData().getString("es_active_colour");
        if (colour.isEmpty() || countRings(player, colour) == 0) {
            player.displayClientMessage(Component.literal("§cСначала надень кольцо и выбери корпус клавишей R."), true);
            return;
        }
        final int cost = 250;
        int current = energy(player, colour);
        if (current < cost) {
            player.displayClientMessage(Component.literal("§cДля конструкции нужно " + cost + " энергии."), true);
            return;
        }
        player.getPersistentData().putInt("es_" + colour + "_energy", current - cost);

        ServerLevel level = player.serverLevel();
        Vector3f rgb = colourVector(colour);
        DustParticleOptions dust = new DustParticleOptions(rgb, 1.65F);
        Vec3 origin = player.position().add(0, 1.0, 0);
        Vec3 forward = new Vec3(player.getLookAngle().x, 0, player.getLookAngle().z);
        if (forward.lengthSqr() < 0.001) forward = new Vec3(0, 0, 1);
        forward = forward.normalize();
        Vec3 right = new Vec3(-forward.z, 0, forward.x);
        Vec3 center = origin.add(forward.scale(2.2));

        // Each corps creates a recognisably different hard-light silhouette.
        switch (colour) {
            case "green" -> { // protective wall
                for (int y = 0; y <= 12; y++) for (int x = -8; x <= 8; x++)
                    if (x % 2 == 0 || y % 2 == 0) constructParticle(level, dust, center.add(right.scale(x * .18)).add(0, y * .18 - 1.0, 0));
            }
            case "yellow" -> { // fear cage
                for (int y = 0; y <= 12; y++) for (int a = 0; a < 4; a++) {
                    double angle = a * Math.PI / 2;
                    constructParticle(level, dust, center.add(Math.cos(angle) * .95, y * .18 - 1.0, Math.sin(angle) * .95));
                }
                for (int y : new int[]{0, 6, 12}) for (int a = 0; a < 32; a++) {
                    double angle = a * Math.PI * 2 / 32;
                    constructParticle(level, dust, center.add(Math.cos(angle) * .95, y * .18 - 1.0, Math.sin(angle) * .95));
                }
            }
            case "red" -> { // burst of jagged spikes
                for (int a = 0; a < 12; a++) {
                    double angle = a * Math.PI * 2 / 12;
                    for (int n = 0; n < 12; n++) {
                        double r = n * .13;
                        constructParticle(level, dust, center.add(Math.cos(angle) * r, Math.sin(angle * 2) * r * .45, Math.sin(angle) * r));
                    }
                }
            }
            case "blue" -> { // rising hope spiral
                for (int i = 0; i < 100; i++) {
                    double t = i / 99.0, a = t * Math.PI * 5;
                    constructParticle(level, dust, center.add(Math.cos(a) * (.2 + t * .85), t * 2.5 - 1.2, Math.sin(a) * (.2 + t * .85)));
                }
            }
            case "orange" -> { // orbiting treasure rings
                for (int ring = 0; ring < 3; ring++) for (int i = 0; i < 48; i++) {
                    double a = i * Math.PI * 2 / 48;
                    double r = .55 + ring * .38;
                    constructParticle(level, dust, center.add(Math.cos(a) * r, Math.sin(a * 2 + ring) * .25, Math.sin(a) * r));
                }
            }
            case "indigo" -> { // compassionate dome
                for (int lat = 0; lat <= 8; lat++) for (int lon = 0; lon < 32; lon++) {
                    double p = -Math.PI / 2 + Math.PI * lat / 8, a = lon * Math.PI * 2 / 32;
                    constructParticle(level, dust, origin.add(Math.cos(p) * Math.cos(a) * 1.5, Math.sin(p) * 1.5, Math.cos(p) * Math.sin(a) * 1.5));
                }
            }
            case "violet" -> { // twin linked hearts, represented by two loops
                for (int side : new int[]{-1, 1}) for (int i = 0; i < 64; i++) {
                    double a = i * Math.PI * 2 / 64;
                    constructParticle(level, dust, center.add(right.scale(side * .55 + Math.cos(a) * .48)).add(0, Math.sin(a) * .48, 0));
                }
            }
            case "black" -> { // descending singularity vortex
                for (int i = 0; i < 120; i++) {
                    double t = i / 119.0, a = t * Math.PI * 8;
                    constructParticle(level, dust, center.add(Math.cos(a) * (1.2 - t * .9), 1.2 - t * 2.4, Math.sin(a) * (1.2 - t * .9)));
                }
            }
            default -> { // white life: radiant sphere
                for (int lat = 0; lat <= 10; lat++) for (int lon = 0; lon < 40; lon++) {
                    double p = -Math.PI / 2 + Math.PI * lat / 10, a = lon * Math.PI * 2 / 40;
                    constructParticle(level, dust, center.add(Math.cos(p) * Math.cos(a) * 1.25, Math.sin(p) * 1.25, Math.cos(p) * Math.sin(a) * 1.25));
                }
            }
        }

        // The formation also has a gameplay effect; it is not just a particle effect.
        List<LivingEntity> affected = level.getEntitiesOfClass(LivingEntity.class,
                player.getBoundingBox().inflate(5.0), e -> e != player && e.isAlive());
        switch (colour) {
            case "green" -> player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 240, 2));
            case "yellow" -> affected.stream().filter(e -> !player.isAlliedTo(e)).forEach(e -> e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 120, 3)));
            case "red" -> affected.stream().filter(e -> !player.isAlliedTo(e)).forEach(e -> e.hurt(player.damageSources().magic(), 5.0F));
            case "blue" -> { player.heal(6.0F); player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 1)); }
            case "orange" -> player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 300, 2));
            case "indigo", "violet" -> affected.stream().filter(player::isAlliedTo).forEach(e -> e.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 1)));
            case "black" -> affected.stream().filter(e -> !player.isAlliedTo(e)).forEach(e -> e.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 1)));
            case "white" -> { player.heal(10.0F); player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 200, 1)); }
        }
        player.displayClientMessage(Component.literal("§bКонструкция создана: §f" + displayName(colour) + " §7(-" + cost + " энергии)"), true);
    }

    private static void constructParticle(ServerLevel level, DustParticleOptions dust, Vec3 point) {
        level.sendParticles(dust, point.x, point.y, point.z, 1, 0.015, 0.015, 0.015, 0.0);
    }

    public static void toggleFlight(ServerPlayer player) {
        boolean hasRing = !availableColours(player).isEmpty();
        if (player.isCreative() || player.isSpectator()) {
            player.displayClientMessage(Component.literal("§7В творческом режиме полёт уже доступен."), true);
            return;
        }
        if (!hasRing) {
            player.displayClientMessage(Component.literal("§cДля полёта необходимо надеть кольцо Фонарей."), true);
            return;
        }
        boolean enabled = !player.getPersistentData().getBoolean("es_flight_enabled");
        player.getPersistentData().putBoolean("es_flight_enabled", enabled);
        if (enabled) {
            player.getAbilities().mayfly = true;
            player.getAbilities().flying = true;
            player.displayClientMessage(Component.literal("§bПолёт включён."), true);
        } else {
            player.getAbilities().flying = false;
            player.getAbilities().mayfly = false;
            player.displayClientMessage(Component.literal("§7Полёт выключен."), true);
        }
        player.onUpdateAbilities();
    }

    private static Vector3f colourVector(String colour) {
        return switch (colour) {
            case "green" -> new Vector3f(0.08F, 0.95F, 0.30F);
            case "yellow" -> new Vector3f(1.0F, 0.88F, 0.05F);
            case "red" -> new Vector3f(0.95F, 0.05F, 0.08F);
            case "blue" -> new Vector3f(0.08F, 0.35F, 1.0F);
            case "orange" -> new Vector3f(1.0F, 0.42F, 0.02F);
            case "indigo" -> new Vector3f(0.30F, 0.08F, 0.75F);
            case "violet" -> new Vector3f(0.95F, 0.15F, 0.65F);
            case "black" -> new Vector3f(0.12F, 0.12F, 0.15F);
            default -> new Vector3f(0.92F, 0.95F, 1.0F);
        };
    }
\n    public static String displayName(String colour) {
        return switch (colour) {
            case "green" -> "§aЗелёный Фонарь";
            case "yellow" -> "§eЖёлтый Фонарь";
            case "red" -> "§cКрасный Фонарь";
            case "blue" -> "§9Синий Фонарь";
            case "orange" -> "§6Оранжевый Фонарь";
            case "indigo" -> "§5Индиго";
            case "violet" -> "§dФиолетовый Фонарь";
            case "black" -> "§8Чёрный Фонарь";
            case "white" -> "§fБелый Фонарь";
            default -> colour;
        };
    }

    private SpectrumLogic() {}
}
