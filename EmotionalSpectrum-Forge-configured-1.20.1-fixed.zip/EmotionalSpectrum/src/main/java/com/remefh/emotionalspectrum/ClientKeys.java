package com.remefh.emotionalspectrum;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = EmotionalSpectrum.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ClientKeys {
    public static KeyMapping CYCLE;
    public static KeyMapping ACTIVATE;
    public static KeyMapping FLIGHT;
    public static KeyMapping BEAM;
    public static KeyMapping CONSTRUCT;

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        CYCLE = new KeyMapping("key.emotional_spectrum.cycle", InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_R, "key.categories.emotional_spectrum");
        ACTIVATE = new KeyMapping("key.emotional_spectrum.activate", InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_V, "key.categories.emotional_spectrum");
        FLIGHT = new KeyMapping("key.emotional_spectrum.flight", InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_B, "key.categories.emotional_spectrum");
        BEAM = new KeyMapping("key.emotional_spectrum.beam", InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_C, "key.categories.emotional_spectrum");
        event.register(CYCLE);
        event.register(ACTIVATE);
        event.register(FLIGHT);
        event.register(BEAM);
        CONSTRUCT = new KeyMapping("key.emotional_spectrum.construct", InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_G, "key.categories.emotional_spectrum");
        event.register(CONSTRUCT);
    }

    @Mod.EventBusSubscriber(modid = EmotionalSpectrum.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static class InputHandler {
        @SubscribeEvent
        public static void onClientTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END) return;
            while (CYCLE != null && CYCLE.consumeClick()) {
                NetworkHandler.CHANNEL.sendToServer(new RingActionPacket(0));
            }
            while (ACTIVATE != null && ACTIVATE.consumeClick()) {
                NetworkHandler.CHANNEL.sendToServer(new RingActionPacket(1));
            }
            while (FLIGHT != null && FLIGHT.consumeClick()) {
                NetworkHandler.CHANNEL.sendToServer(new RingActionPacket(2));
            }
            while (BEAM != null && BEAM.consumeClick()) {
                NetworkHandler.CHANNEL.sendToServer(new RingActionPacket(3));
            }
            while (CONSTRUCT != null && CONSTRUCT.consumeClick()) {
                NetworkHandler.CHANNEL.sendToServer(new RingActionPacket(4));
            }
        }
    }
}
