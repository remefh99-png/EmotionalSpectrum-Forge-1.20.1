package com.remefh.emotionalspectrum;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class SpectrumSyncPacket {
    private final int[] energy;
    private final int[] max;
    private final String active;

    public SpectrumSyncPacket(int[] energy, int[] max, String active) {
        this.energy = energy.clone();
        this.max = max.clone();
        this.active = active;
    }

    public static void encode(SpectrumSyncPacket packet, FriendlyByteBuf buffer) {
        for (int i = 0; i < 9; i++) {
            buffer.writeVarInt(packet.energy[i]);
            buffer.writeVarInt(packet.max[i]);
        }
        buffer.writeUtf(packet.active, 16);
    }

    public static SpectrumSyncPacket decode(FriendlyByteBuf buffer) {
        int[] energy = new int[9];
        int[] max = new int[9];
        for (int i = 0; i < 9; i++) {
            energy[i] = buffer.readVarInt();
            max[i] = buffer.readVarInt();
        }
        return new SpectrumSyncPacket(energy, max, buffer.readUtf(16));
    }

    public static void handle(SpectrumSyncPacket packet, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientSpectrumData.update(packet.energy, packet.max, packet.active)));
        context.setPacketHandled(true);
    }
}
