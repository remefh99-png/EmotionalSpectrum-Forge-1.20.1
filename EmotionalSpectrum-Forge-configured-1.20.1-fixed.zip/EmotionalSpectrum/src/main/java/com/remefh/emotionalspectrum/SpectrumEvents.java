package com.remefh.emotionalspectrum;

import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.network.PacketDistributor;

public class SpectrumEvents {
    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.player.level().isClientSide) return;
        if (!(event.player instanceof ServerPlayer player) || player.tickCount % 20 != 0) return;

        for (String colour : SpectrumLogic.COLOURS) {
            int count = SpectrumLogic.countRings(player, colour);
            int max = count * 1000;
            String energyKey = "es_" + colour + "_energy";
            player.getPersistentData().putInt("es_" + colour + "_rings", count);
            player.getPersistentData().putInt("es_" + colour + "_max_energy", max);

            int energy = player.getPersistentData().getInt(energyKey);
            if (count == 0) {
                player.getPersistentData().putInt(energyKey, 0);
            } else {
                player.getPersistentData().putInt(energyKey, Math.min(max, energy + 10));
            }
        }

        if (player.getPersistentData().getBoolean("es_flight_enabled")
                && SpectrumLogic.availableColours(player).isEmpty()) {
            player.getPersistentData().putBoolean("es_flight_enabled", false);
            player.getAbilities().flying = false;
            player.getAbilities().mayfly = false;
            player.onUpdateAbilities();
        }

        String active = player.getPersistentData().getString("es_active_colour");
        if (!active.isEmpty() && SpectrumLogic.countRings(player, active) == 0) {
            player.getPersistentData().putString("es_active_colour", "");
            active = "";
        }

        int[] syncedEnergy = new int[9];
        int[] syncedMax = new int[9];
        for (int i = 0; i < SpectrumLogic.COLOURS.length; i++) {
            String colour = SpectrumLogic.COLOURS[i];
            syncedEnergy[i] = player.getPersistentData().getInt("es_" + colour + "_energy");
            syncedMax[i] = player.getPersistentData().getInt("es_" + colour + "_max_energy");
        }
        NetworkHandler.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                new SpectrumSyncPacket(syncedEnergy, syncedMax,
                        player.getPersistentData().getString("es_active_colour")));

    }
}
