package com.remefh.emotionalspectrum;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import java.util.List;

public class LanternRingItem extends Item {
    private final String spectrum;
    private final int colour;

    public LanternRingItem(Properties properties, String spectrum, int colour) {
        super(properties);
        this.spectrum = spectrum;
        this.colour = colour;
    }

    public String getSpectrum() { return spectrum; }
    public int getColour() { return colour; }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§7Emotional Spectrum: §f" + spectrum));
        tooltip.add(Component.literal("§7Energy per ring: §b1,000"));
        tooltip.add(Component.literal("§8Wear multiple rings to increase this colour's reserve."));
        super.appendHoverText(stack, level, tooltip, flag);
    }
}
