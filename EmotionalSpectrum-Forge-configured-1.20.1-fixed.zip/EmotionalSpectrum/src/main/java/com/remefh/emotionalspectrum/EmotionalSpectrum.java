package com.remefh.emotionalspectrum;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(EmotionalSpectrum.MODID)
public class EmotionalSpectrum {
    public static final String MODID = "emotional_spectrum";

    public EmotionalSpectrum() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(modBus);
        NetworkHandler.register();
        MinecraftForge.EVENT_BUS.register(new SpectrumEvents());
    }
}
