package com.remefh.emotionalspectrum;

import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class NetworkHandler {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(EmotionalSpectrum.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private static boolean registered = false;

    public static void register() {
        if (registered) return;
        registered = true;
        CHANNEL.registerMessage(0, RingActionPacket.class,
                RingActionPacket::encode, RingActionPacket::decode, RingActionPacket::handle);
        CHANNEL.registerMessage(1, SpectrumSyncPacket.class,
                SpectrumSyncPacket::encode, SpectrumSyncPacket::decode, SpectrumSyncPacket::handle);
    }

    private NetworkHandler() {}
}
