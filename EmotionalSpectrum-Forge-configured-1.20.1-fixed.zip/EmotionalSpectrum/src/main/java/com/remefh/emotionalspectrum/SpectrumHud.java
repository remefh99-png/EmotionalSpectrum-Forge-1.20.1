package com.remefh.emotionalspectrum;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = EmotionalSpectrum.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public class SpectrumHud {
    private static final int[] COLOURS = {
        0x35E879, 0xF5D735, 0xF04B50, 0x4D91FF, 0xF39A35,
        0x8D69E8, 0xED75D2, 0xA0A0A0, 0xF4F4F4
    };

    @SubscribeEvent
    public static void registerOverlays(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll(new ResourceLocation(EmotionalSpectrum.MODID, "spectrum_hud"),
                (gui, graphics, partialTick, width, height) -> {
                    Minecraft minecraft = Minecraft.getInstance();
                    if (minecraft.player == null || minecraft.options.hideGui) return;

                    int y = 8;
                    boolean any = false;
                    for (int i = 0; i < 9; i++) {
                        int max = ClientSpectrumData.MAX[i];
                        if (max <= 0) continue;
                        any = true;
                        String name = ClientSpectrumData.COLOURS[i];
                        String marker = name.equals(ClientSpectrumData.ACTIVE) ? "▶ " : "  ";
                        String line = marker + title(name) + "  "
                                + ClientSpectrumData.ENERGY[i] + "/" + max;
                        graphics.drawString(minecraft.font, Component.literal(line),
                                8, y, COLOURS[i], true);
                        y += 10;
                    }
                    if (any) {
                        graphics.drawString(minecraft.font,
                                Component.literal("Emotional Spectrum"),
                                8, y + 2, 0xFFFFFF, true);
                    }
                });
    }

    private static String title(String value) {
        return value.substring(0, 1).toUpperCase() + value.substring(1);
    }
}
