package com.remefh.emotionalspectrum;

import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
        DeferredRegister.create(ForgeRegistries.ITEMS, EmotionalSpectrum.MODID);

    public static final RegistryObject<Item> GREEN_RING = ring("green", 0x20D66B);
    public static final RegistryObject<Item> YELLOW_RING = ring("yellow", 0xF5D328);
    public static final RegistryObject<Item> RED_RING = ring("red", 0xE52B35);
    public static final RegistryObject<Item> BLUE_RING = ring("blue", 0x287DEB);
    public static final RegistryObject<Item> ORANGE_RING = ring("orange", 0xF28B22);
    public static final RegistryObject<Item> INDIGO_RING = ring("indigo", 0x5635B5);
    public static final RegistryObject<Item> VIOLET_RING = ring("violet", 0xE34EBB);
    public static final RegistryObject<Item> BLACK_RING = ring("black", 0x292929);
    public static final RegistryObject<Item> WHITE_RING = ring("white", 0xF1F1F1);

    private static RegistryObject<Item> ring(String name, int colour) {
        return ITEMS.register(name + "_lantern_ring",
            () -> new LanternRingItem(new Item.Properties().stacksTo(1), name, colour));
    }

    private ModItems() {}
}
